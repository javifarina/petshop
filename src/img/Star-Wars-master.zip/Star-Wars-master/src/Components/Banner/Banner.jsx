import React from 'react';
import './Banner.css'

export default function Banner(){
    return (
       
        <div className= 'banner'>
            <img src='https://i.pinimg.com/564x/3b/23/02/3b2302859a1edf5596f783934a6d9d7a.jpg' className='imgBanner'></img>
        </div>
        
    )
}

